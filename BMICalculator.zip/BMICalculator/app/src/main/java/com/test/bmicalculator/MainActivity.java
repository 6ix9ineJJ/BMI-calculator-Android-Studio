package com.test.bmicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText editText1;
    EditText editText2;
    Button calculateBtn;
    TextView bmiScore;
    TextView bmiCategory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText1 = (EditText) findViewById(R.id.editTextKG);
        editText2 = (EditText) findViewById(R.id.editTextMeter);
        calculateBtn = (Button) findViewById(R.id.button);
        bmiScore = (TextView) findViewById(R.id.textView3);
        bmiCategory = (TextView) findViewById(R.id.textView6);

        calculateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bmiScore.setText(editText1.getText().toString());
                bmiCategory.setText(editText2.getText().toString());
            }
        });
    }
}